# Periodización de pacientes

App web instalable (PWA). Es una sola página estática: no necesita servidor ni compilar nada.

## Publicar en GitHub Pages
1. Sube todos los archivos y la carpeta `icons` a la raíz del repositorio.
2. En el repositorio: Settings → Pages → Source: "Deploy from a branch" → rama `main` y carpeta `/ (root)` → Save.
3. Espera un minuto y abre `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Importante
- Los datos (pacientes, sesiones, registros de banda) se guardan solo en el navegador de cada dispositivo. Usa "Descargar respaldo" dentro de la app para llevarlos a otro equipo o resguardarlos.
- Si el repositorio es público, la app es pública (los datos no, porque no se suben). Para proteger el acceso usa un repositorio privado con Pages de pago o publica en otro servicio.
- Para actualizar la app: reemplaza `index.html` en el repositorio. Si no ves el cambio, cierra y vuelve a abrir la app (el service worker se actualiza solo). Si quieres forzarlo, cambia `periodizacion-v1` por `v2` en `sw.js`.
- La generación de PDF carga dos librerías desde internet la primera vez (cdnjs.cloudflare.com).
